# Gemini Blog Bot

This repository automatically generates daily blog posts using the Gemini API and publishes them via GitHub Pages.

All posts are tagged with #KG-NINJA.

Visit my support page:
👉 [BuyMeACoffee - KG](https://buymeacoffee.com/kgninja)
